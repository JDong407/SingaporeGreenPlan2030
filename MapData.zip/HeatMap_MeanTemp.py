# 导入 pandas 和 plotly.express 库
import pandas as pd
import plotly.express as px

# 从 CSV 文件中读取数据，使用 'ISO-8859-1' 编码
map_data = pd.read_csv('MapData.csv', encoding='ISO-8859-1')
station_coordinates = pd.read_csv('StationCoordinates.csv', encoding='ISO-8859-1')

# 将 'Year' 和 'Month' 字段结合起来，并转换成 datetime 类型
map_data['Date'] = pd.to_datetime(
    map_data['Year'].astype(str) + '-' + map_data['Month'],
    format='%Y-%B'
)

# 设置起止日期
start_date = pd.to_datetime("2013-01-01")
end_date = pd.to_datetime("2023-09-30")

# 筛选出在指定日期范围内的数据
map_data_filtered = map_data[(map_data['Date'] >= start_date) & (map_data['Date'] <= end_date)]

# 删除 'Mean Temperature' 字段为空的行
map_data_filtered = map_data_filtered.dropna(subset=['Mean Temperature'])

# 创建一个新的列 'Year-Month'，用于动画帧的标签
map_data_filtered['Year-Month'] = map_data_filtered['Date'].dt.strftime('%b %Y')

# 生成从开始日期到结束日期的月初序列
dates = pd.date_range(start=start_date, end=end_date, freq='MS')
year_month_pairs = [date.strftime('%b %Y') for date in dates]

# 将过滤后的温度数据和站点坐标数据合并
heatmap_data = pd.merge(map_data_filtered, station_coordinates, left_on='Station', right_on='Location')
heatmap_data = heatmap_data[heatmap_data['Year-Month'].isin(year_month_pairs)]

# 设置 'Year-Month' 为有序的分类数据类型，以保证动画的顺序正确
heatmap_data['Year-Month'] = pd.Categorical(heatmap_data['Year-Month'], categories=year_month_pairs, ordered=True)
heatmap_data.sort_values('Year-Month', inplace=True)

# 获取 'Mean Temperature' 的最大值，用于后续设置散点图的大小比例
global_max = heatmap_data["Mean Temperature"].max()
sizeref_value = 2. * global_max / (15 ** 2)

# 创建一个散点地理图表，展示新加坡的月平均温度
fig = px.scatter_geo(
    heatmap_data,
    lat='lat',
    lon='lon',
    color="Mean Temperature",
    size="Mean Temperature",
    animation_frame="Year-Month",
    hover_name="Station",
    projection="natural earth",
    title="Monthly Mean Temperature in Singapore (Jan 2013 - Sep 2023)",
    template="plotly",
    locationmode='country names',
    color_continuous_scale=px.colors.sequential.YlOrBr
)

# 更新散点图的追踪器，设置大小比例和边框
fig.update_traces(marker=dict(
    sizeref=sizeref_value,
    sizemin=4,
    line=dict(width=1, color='White')
))

# 更新地图的地理设置，包括分辨率、国家边界、中心点坐标等
fig.update_geos(
    resolution=50,
    showcountries=True,
    countrycolor="Black",
    center={"lat": 1.3521, "lon": 103.8198},
    lataxis={"range": [1.16, 1.47]},
    lonaxis={"range": [103.58, 104.10]},
    landcolor='rgb(187,218,164)',
    oceancolor='rgb(155,191,244)',
    showocean=True,
    bgcolor='rgba(0,0,0,0)'
)

# 更新整个图表的布局设置，包括背景颜色和边距
fig.update_layout(
    geo=dict(bgcolor='rgba(0,0,0,0)'),
    paper_bgcolor='rgba(0,0,0,0)',
    margin={"r":0,"t":0,"l":0,"b":0}
)

# 将图表保存为 HTML 文件
fig.write_html("singapore_meanTemperature_heatmap.html")

# 显示图表
fig.show()
