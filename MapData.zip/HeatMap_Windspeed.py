# 导入 pandas 和 plotly.express 库
import pandas as pd
import plotly.express as px

# 读取数据集
map_data = pd.read_csv('MapData.csv', encoding='ISO-8859-1')
station_coordinates = pd.read_csv('StationCoordinates.csv', encoding='ISO-8859-1')

# 将年份和月份合并，并转换为日期时间格式
map_data['Date'] = pd.to_datetime(
    map_data['Year'].astype(str) + '-' + map_data['Month'],
    format='%Y-%B'
)

# 设置开始日期和结束日期
start_date = pd.to_datetime("2013-01-01")
end_date = pd.to_datetime("2023-09-30")

# 筛选在开始日期和结束日期之间的数据
map_data_filtered = map_data[(map_data['Date'] >= start_date) & (map_data['Date'] <= end_date)]

# 删除缺失平均风速数据的行
map_data_filtered = map_data_filtered.dropna(subset=['Mean Wind Speed (km/h)'])

# 生成 'Year-Month' 格式的列，用于后续的动画帧显示
map_data_filtered['Year-Month'] = map_data_filtered['Date'].dt.strftime('%b %Y')

# 生成从开始日期到结束日期的每个月的时间序列
dates = pd.date_range(start=start_date, end=end_date, freq='MS')
year_month_pairs = [date.strftime('%b %Y') for date in dates]

# 合并地图数据和站点坐标数据
heatmap_data = pd.merge(map_data_filtered, station_coordinates, left_on='Station', right_on='Location')
# 确保仅包含时间序列中的年月
heatmap_data = heatmap_data[heatmap_data['Year-Month'].isin(year_month_pairs)]

# 对数据进行排序，确保动画的顺序与年月匹配
heatmap_data['Year-Month'] = pd.Categorical(heatmap_data['Year-Month'], categories=year_month_pairs, ordered=True)
heatmap_data.sort_values('Year-Month', inplace=True)

# 获取风速的最大值，用于散点图的大小设置
global_max = heatmap_data["Mean Wind Speed (km/h)"].max()
sizeref_value = 2. * global_max / (15 ** 2)

# 创建一个散点地理图表示新加坡每月的平均风速
fig = px.scatter_geo(
    heatmap_data,
    lat='lat',
    lon='lon',
    color="Mean Wind Speed (km/h)",
    size="Mean Wind Speed (km/h)",
    animation_frame="Year-Month",
    hover_name="Station",
    projection="natural earth",
    title="Monthly Mean Wind Speed (km/h) in Singapore (Jan 2013 - Sep 2023)",
    template="plotly",
    locationmode='country names',
    color_continuous_scale=px.colors.sequential.Purples  # 使用紫色调的连续色阶
)

# 更新图表的标记设置，包括大小、最小值和边框
fig.update_traces(marker=dict(
    sizeref=sizeref_value,
    sizemin=4,
    line=dict(width=1, color='White')
))

# 更新地图的地理设置
fig.update_geos(
    resolution=50,
    showcountries=True,
    countrycolor="Black",
    center={"lat": 1.3521, "lon": 103.8198},  # 设置中心点为新加坡的坐标
    lataxis={"range": [1.16, 1.47]},  # 纬度范围
    lonaxis={"range": [103.58, 104.10]},  # 经度范围
    landcolor='rgb(187,218,164)',  # 陆地颜色
    oceancolor='rgb(155,191,244)',  # 海洋颜色
    showocean=True,
    bgcolor='rgba(0,0,0,0)'  # 背景颜色
)

# 更新整体布局设置
fig.update_layout(
    geo=dict(bgcolor='rgba(0,0,0,0)'),
    paper_bgcolor='rgba(0,0,0,0)',
    margin={"r":0,"t":0,"l":0,"b":0}  # 边距设置
)

# 将图表保存为 HTML 文件，用于网页中嵌入或独立显示
fig.write_html("singapore_windspeed_heatmap.html")

# 显示图表，适用于 Jupyter Notebook 等交互式环境
fig.show()
