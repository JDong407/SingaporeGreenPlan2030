# 导入 pandas 和 plotly.express 模块
import pandas as pd
import plotly.express as px

# 从 CSV 文件加载数据，并指定编码
map_data = pd.read_csv('MapData.csv', encoding='ISO-8859-1')
station_coordinates = pd.read_csv('StationCoordinates.csv', encoding='ISO-8859-1')

# 将年份和月份组合转换为 datetime 类型，以便正确地过滤和排序数据
map_data['Date'] = pd.to_datetime(
    map_data['Year'].astype(str) + '-' + map_data['Month'],
    format='%Y-%B'  # 根据您数据集中的月份格式调整
)

# 保证从2013年1月到2023年9月的正确过滤
start_date = pd.to_datetime("2013-01-01")
end_date = pd.to_datetime("2023-09-30")
map_data_filtered = map_data[(map_data['Date'] >= start_date) & (map_data['Date'] <= end_date)]

# 在绘图前删除 'Daily Rainfall Total (mm)' 中的 NaN 值
map_data_filtered = map_data_filtered.dropna(subset=['Daily Rainfall Total (mm)'])

# 为 Plotly 的 animation_frame 创建一个 'Year-Month' 列
map_data_filtered['Year-Month'] = map_data_filtered['Date'].dt.strftime('%b %Y')

# 生成从2013年1月到2023年9月的年-月对列表
dates = pd.date_range(start=start_date, end=end_date, freq='MS')  # MS 是月初频率
year_month_pairs = [date.strftime('%b %Y') for date in dates]

# 过滤 map_data_filtered，仅包含 'Year-Month' 在我们生成列表中的行
heatmap_data = pd.merge(map_data_filtered, station_coordinates, left_on='Station', right_on='Location')
heatmap_data = heatmap_data[heatmap_data['Year-Month'].isin(year_month_pairs)]

# 按照 'Year-Month' 的列表对 heatmap_data 进行排序，以确保顺序正确
heatmap_data['Year-Month'] = pd.Categorical(heatmap_data['Year-Month'], categories=year_month_pairs, ordered=True)
heatmap_data.sort_values('Year-Month', inplace=True)

# 确定 'Daily Rainfall Total (mm)' 的全局最大值，用于设置 sizeref
global_max = heatmap_data["Daily Rainfall Total (mm)"].max()
sizeref_value = 2. * global_max / (15 ** 2)

# 创建散点地理图
fig = px.scatter_geo(
    heatmap_data,
    lat='lat',
    lon='lon',
    color="Daily Rainfall Total (mm)",
    size="Daily Rainfall Total (mm)",  # 添加了大小属性
    animation_frame="Year-Month",
    hover_name="Station",
    projection="natural earth",
    title="Monthly Average Daily Rainfall Total (mm) in Singapore (Jan 2013 - Sep 2023)",
    template="plotly",
    locationmode='country names',
    color_continuous_scale=px.colors.sequential.Blues
)

# 使用全局 sizeref 和 sizemin 更新追踪器，设置标记的最小大小
fig.update_traces(marker=dict(
    sizeref=sizeref_value,
    sizemin=4,
    line=dict(width=1, color='White')  # 为标记添加指定颜色和宽度的边框
))

# 更新布局以聚焦新加坡，使用与第一部分相同的设置
fig.update_geos(
    resolution=50,
    showcountries=True,
    countrycolor="Black",
    center={"lat": 1.3521, "lon": 103.8198},
    lataxis={"range": [1.16, 1.47]},
    lonaxis={"range": [103.58, 104.10]},
    landcolor='rgb(187,218,164)',
    oceancolor='rgb(155,191,244)',
    showocean=True,
    bgcolor='rgba(0,0,0,0)'
)

# 更新布局，使背景透明，与第一部分相同
fig.update_layout(
    geo=dict(bgcolor='rgba(0,0,0,0)'),
    paper_bgcolor='rgba(0,0,0,0)',
    margin={"r":0,"t":0,"l":0,"b":0}
)

# 将图表保存为 HTML 文件
fig.write_html("singapore_rainfall_heatmap.html")

# 如果您使用的是交互式环境（如 Jupyter），则显示图表
fig.show()
